export const apiURL: string = 'http://localhost:8880/nouriture/api';
